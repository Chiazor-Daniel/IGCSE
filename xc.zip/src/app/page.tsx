import GeneratorPage from "./generator-page";

export default function Home() {
  return (
    <main>
      <GeneratorPage />
    </main>
  )
}
