import { NextRequest, NextResponse } from 'next/server';
import { solveQuestion } from '@/ai/flows/solve-question';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { question, subject, answer } = body;

    if (!question || !subject || !answer) {
      return NextResponse.json(
        { error: 'Missing required parameters: question, subject, and answer are required' },
        { status: 400 }
      );
    }

    // Combine the question and student's answer for evaluation
    const fullQuestion = `Question: ${question}\n\nStudent's Answer: ${answer}`;

    const result = await solveQuestion({
      question: fullQuestion,
      subject,
    });

    return NextResponse.json({ 
      solution: result.solution,
    });
  } catch (error) {
    console.error('Error evaluating theory answer:', error);
    return NextResponse.json(
      { error: 'Failed to evaluate theory answer' },
      { status: 500 }
    );
  }
}
